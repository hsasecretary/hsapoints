// Seeds the local emulators with test accounts and a Fall 2026 of codes, so
// Submit Point Request's Missed Events, Strikes and Make-ups can be tried
// without touching the live project. Wipes the emulators first.
//
//   npm run emulator:demo   (leave running)
//   npm run seed:demo       (waits for the emulator to finish starting)
//   npm run dev:emulator    then sign in with an account below
//
// Test-only accounts; they exist only in the local Auth emulator.
import { initializeTestEnvironment } from '@firebase/rules-unit-testing';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';

const PROJECT = 'demo-hsapoints';
const AUTH = 'http://127.0.0.1:9099';
const PASSWORD = 'hsa-demo-2026';

const CABINET = 'cabinet.demo@ufl.edu';
const GENERAL = 'general.demo@ufl.edu';
const EBOARD = 'eboard.demo@ufl.edu';
const MLP_SPRING = 'mlp.demo@ufl.edu';

// Fall 2026. Dated around 2026-09-26: the last two Core Events are upcoming
// until October.
const codes = {
    ORIENT: ['Cabinet Orientation', 'cabinet-orientation', '2026-08-23'],
    GBM1: ['GBM 1', 'gbm', '2026-08-27'],
    CT1: ['Cabinet Thursday 1', 'cabinet-thursday', '2026-08-28'],
    GBM2: ['GBM 2', 'gbm', '2026-09-03'],
    CT2: ['Cabinet Thursday 2', 'cabinet-thursday', '2026-09-04'],
    OPA1: ['OPA General Body', 'opa-general', '2026-09-05'],
    RETREAT: ['Cabinet Retreat', 'cabinet-retreat', '2026-09-06'],
    GBM3: ['GBM 3', 'gbm', '2026-09-10'],
    CT3: ['Cabinet Thursday 3', 'cabinet-thursday', '2026-09-11'],
    PROG1: ['Noche de Salsa', 'hsa-programming', '2026-09-12'],
    EXT1: ['Welcome Back Social', 'external-social', '2026-09-13'],
    FUND1: ['Empanada Sale', 'hsa-fundraising', '2026-09-14'],
    AFF1: ['SALSA Mixer', 'affiliate-org', '2026-09-16'],
    HLSA1: ['HLSA Kickoff', 'hlsa', '2026-09-17'],
    CT4: ['Cabinet Thursday 4', 'cabinet-thursday', '2026-09-18'],
    OPA2: ['OPA Town Hall', 'opa-general', '2026-09-19'],
    SERV1: ['Park Cleanup', 'hsa-service', '2026-09-20'],
    SOLID1: ['OPA Solidarity Session', 'opa-solidarity-session', '2026-09-22'],
    GBM4: ['GBM 4', 'gbm', '2026-09-24'],
    CT5: ['Cabinet Thursday 5', 'cabinet-thursday', '2026-09-25'],
    CT6: ['Cabinet Thursday 6', 'cabinet-thursday', '2026-10-02'],
    GBM5: ['GBM 5', 'gbm', '2026-10-08'],
};

function user(email, firstName, overrides) {
    return {
        email, firstName, lastName: 'Demo', graduationYear: '2028', involvement: 'general',
        cabinet: 'none', position: '', eboard: false, approved: false,
        fallPoints: 0, springPoints: 0, strikes: 0, eventCodes: [], cabinetPoints: 0, otherPoints: 0,
        ...overrides,
    };
}

function attended(email, codeId) {
    const [, eventTypeId, eventDate] = codes[codeId];
    return [`attendances/${email}__${codeId}`, { email, eventTypeId, eventDate, source: 'code', codeId }];
}

const docs = Object.fromEntries([
    ...Object.entries(codes).map(([id, [event, eventTypeId, eventDate]]) =>
        [`codes/${id}`, { event, eventTypeId, eventDate, attendeeCount: 0 }]),

    // Cabinet Member: misses CT1, GBM2, RETREAT, GBM3, CT3 and HLSA1.
    // OPA2 is Surplus and makes up CT1 (the oldest Strike), CT3 is excused
    // (owed, no Strike), and a pending request names GBM3. That leaves 4 open
    // Strikes: at risk. On Excuse Absence, excusing CT1 moves OPA2 onto GBM2.
    [`users/${CABINET}`, user(CABINET, 'Cara', {
        involvement: 'cabinet', cabinet: 'programming', approved: true,
        excusals: [{ codeId: 'CT3', note: 'Excuse Form: exam', by: EBOARD, at: '2026-09-12T15:00:00.000Z' }],
        absenceLog: [{ kind: 'excused', codeId: 'CT3', note: 'Excuse Form: exam', by: EBOARD, at: '2026-09-12T15:00:00.000Z' }],
    })],
    ...['ORIENT', 'GBM1', 'CT2', 'OPA1', 'CT4', 'OPA2', 'GBM4', 'CT5'].map((id) => attended(CABINET, id)),
    ['pointRequests/demo-pending-makeup', {
        userEmail: CABINET, codeId: 'FUND1', typeChoiceId: 'hsa-fundraising', eventTypeId: 'hsa-fundraising',
        activityName: 'Empanada Sale', date: '2026-09-14', description: '', makeupFor: ['GBM3'], imageData: '',
        pointsRequested: 2, status: 'pending', reviewedAt: null, reviewedBy: null, reviewNotes: '',
        submittedAt: serverTimestamp(),
    }],
    // Three Tabling hours for E-Board's review (#72): the first fills the
    // Semester Requirement, the other two are Make-ups.
    ['pointRequests/demo-pending-tabling', {
        userEmail: CABINET, codeId: null, typeChoiceId: 'tabling', eventTypeId: 'tabling',
        activityName: 'Turlington table', date: '2026-09-23', description: 'Tabled for the fundraiser', hours: 3,
        makeupFor: [null, null, 'CT3'], imageData: '', pointsRequested: 3, status: 'pending', reviewedAt: null,
        reviewedBy: null, reviewNotes: '', submittedAt: serverTimestamp(),
    }],

    // General Member: search only, no Strikes.
    [`users/${GENERAL}`, user(GENERAL, 'Gabi', {})],
    ...['GBM1', 'OPA1', 'EXT1', 'GBM4'].map((id) => attended(GENERAL, id)),
    // "Not listed": E-Board picks the Event Type, attaches it to PROG1, or makes it an Adjustment.
    ['pointRequests/demo-pending-not-listed', {
        userEmail: GENERAL, codeId: null, typeChoiceId: 'not-listed', eventTypeId: null,
        activityName: 'Salsa night setup', date: '2026-09-12', description: 'Helped set up the dance floor', makeupFor: [null],
        imageData: '', pointsRequested: 0, status: 'pending', reviewedAt: null, reviewedBy: null, reviewNotes: '',
        submittedAt: serverTimestamp(),
    }],

    // MLP Spring member: a goal of 8 VE Points, not 15 (6 so far).
    [`users/${MLP_SPRING}`, user(MLP_SPRING, 'Mateo', { involvement: 'mlp', mlpCohort: 'spring' })],
    ...['GBM1', 'GBM2', 'FUND1'].map((id) => attended(MLP_SPRING, id)),

    // E-Board: reviews the requests above on /eboard/point-requests. Held to
    // the General goal of 15 and past it (16), so the Overview shows gold.
    [`users/${EBOARD}`, user(EBOARD, 'Eva', { involvement: 'eboard', eboard: true, position: 'secretary' })],
    ...['GBM1', 'GBM2', 'OPA1', 'GBM3', 'PROG1', 'FUND1', 'AFF1', 'HLSA1', 'SERV1', 'SOLID1', 'GBM4']
        .map((id) => attended(EBOARD, id)),
]);

async function createAccount(email) {
    const response = await fetch(`${AUTH}/identitytoolkit.googleapis.com/v1/accounts:signUp?key=demo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: PASSWORD, returnSecureToken: true }),
    });
    if (!response.ok) throw new Error(`Creating ${email}: ${await response.text()}`);
}

// emulator:demo takes 60-90s to open its ports; wait for both instead of failing with ECONNREFUSED.
async function waitForEmulators(timeoutMs = 180000) {
    const deadline = Date.now() + timeoutMs;
    for (const url of [AUTH, 'http://127.0.0.1:8080']) {
        for (;;) {
            try { await fetch(url); break; } catch {
                if (Date.now() > deadline) throw new Error(`Emulator at ${url} did not start. Is "npm run emulator:demo" running?`);
                await new Promise((resolve) => setTimeout(resolve, 2000));
            }
        }
    }
}
await waitForEmulators();

const env = await initializeTestEnvironment({ projectId: PROJECT, firestore: { host: '127.0.0.1', port: 8080 } });
await env.clearFirestore();
await fetch(`${AUTH}/emulator/v1/projects/${PROJECT}/accounts`, { method: 'DELETE' });

await env.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    for (const [path, data] of Object.entries(docs)) await setDoc(doc(db, path), data);
});
for (const email of [CABINET, GENERAL, EBOARD, MLP_SPRING]) await createAccount(email);
await env.cleanup();

console.log(`Seeded ${Object.keys(docs).length} docs. Sign in as ${CABINET}, ${GENERAL}, ${EBOARD} or ${MLP_SPRING} (password in this file).`);
