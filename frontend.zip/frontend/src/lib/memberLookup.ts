// What E-Board sees on User Lookup (#37): one Member's standing for the
// school year, every point behind it and where it came from, and their Point
// Requests with who reviewed them. Pure, so it's tested without Firestore;
// every number comes from computeStanding and the rubric, never from a
// stored counter, so it always matches the Member's own dashboard.
import { AT_RISK_STRIKES, CABINET_POINTS_GOAL, adjustmentsThisYear, computeStanding, type Attendance, type Code, type Member, type MissedEvent, type Semester, type Standing } from './computeStanding';
import { removedThisYear, type MemberRequest, type Revoked } from './pointsOverview';
import { eventType, rubric } from './rubric';
import { academicYear, fromIsoDate, toIsoDate } from './semester';

/** Codes by upper-cased ID: a few older rows were stored in mixed case. */
function codesById(codes: Code[]): Map<string, Code> {
    return new Map(codes.map((row) => [row.id.toUpperCase(), row]));
}

/** Newest first; a row with no date goes last. */
function byDateNewestFirst(a: { date: string }, b: { date: string }): number {
    return (b.date || '0000').localeCompare(a.date || '0000');
}

export type PointSource = Attendance['source'] | 'adjustment';

export const SOURCE_LABEL: Record<PointSource, string> = {
    code: 'Code check-in',
    request: 'Point Request',
    eboard: 'Entered by E-Board',
    adjustment: 'Adjustment',
};

/** One row of the points list: an event (a Tabling request's hours are one row) or an Adjustment. */
export type LookupRow = {
    id: string;
    name: string;
    /** 'YYYY-MM-DD', or '' for an Adjustment with no date. */
    date: string;
    /** The Event Type's label, or 'Adjustment'. */
    eventType: string;
    source: PointSource;
    vePoints: number;
    cabinetPoints: number;
    /** Tabling hours, when more than one Attendance makes up the row. */
    hours?: number;
    /** The code checked in with, whether by the Member, a Point Request or E-Board. */
    codeId: string | null;
    requestId: string | null;
    approvedBy: string | null;
    approvedOn: string | null;
    /** An Entered Attendance: who entered it, when, and the note the Member sees. */
    enteredBy: string | null;
    enteredOn: string | null;
    note: string;
    /** A Removed Check-in or a revoked Point Request: its points are what it
     *  had earned, left out of every total. */
    takenBack: TakenBack | null;
};

/** Who took a row's points back, when and why. */
export type TakenBack = {
    kind: 'removed' | 'revoked';
    reason: string;
    by: string | null;
    on: string | null;
    /** A Removed Check-in E-Board has since credited again: it no longer takes anything away. */
    superseded?: boolean;
};

export type LookupLedger = {
    /** Newest first; an Adjustment with no date goes last. */
    rows: LookupRow[];
    /** Equal to the standing's VE Points (Total Points). */
    vePoints: number;
    /** Equal to the standing's Cabinet Points. */
    cabinetPoints: number;
    /** Rows that count: all but those taken back. */
    counted: number;
    /** How many rows are Adjustments. */
    adjustments: number;
    /** Codes counted this year, and how many of those a Point Request added. */
    codes: { redeemed: number; byRequest: number };
};

export function lookupLedger({ member, attendances, codes, requests, today }: {
    member: Member;
    attendances: Attendance[];
    codes: Code[];
    requests: MemberRequest[];
    today: string;
}): LookupLedger {
    const codeById = codesById(codes);
    const requestById = new Map(requests.map((request) => [request.id, request]));
    const reviewOf = (requestId: string | undefined) => {
        const request = requestId ? requestById.get(requestId) : undefined;
        return { approvedBy: request?.reviewedBy ?? null, approvedOn: request?.reviewedOn ?? null };
    };

    const rows = new Map<string, LookupRow>();
    for (const attendance of attendances) {
        const type = eventType(attendance.eventTypeId);
        const key = attendance.codeId ? `code:${attendance.codeId.toUpperCase()}`
            : attendance.requestId ? `req:${attendance.requestId}`
                : attendance.entryId ? `entry:${attendance.entryId}` : attendance.id;
        const existing = rows.get(key);
        if (existing) {
            existing.vePoints += type?.vePoints ?? 0;
            existing.cabinetPoints += type?.cabinetPoints ?? 0;
            existing.hours = (existing.hours ?? 1) + 1;
            continue;
        }
        const code = attendance.codeId ? codeById.get(attendance.codeId.toUpperCase()) : undefined;
        const request = attendance.requestId ? requestById.get(attendance.requestId) : undefined;
        rows.set(key, {
            id: attendance.id,
            name: code?.event || request?.activityName || attendance.eventName || type?.label || 'Event',
            date: attendance.eventDate,
            eventType: type?.label ?? 'Unknown Event Type',
            source: attendance.source,
            vePoints: type?.vePoints ?? 0,
            cabinetPoints: type?.cabinetPoints ?? 0,
            codeId: attendance.codeId ? code?.id ?? attendance.codeId.toUpperCase() : null,
            requestId: attendance.requestId ?? null,
            ...reviewOf(attendance.requestId),
            enteredBy: attendance.enteredBy ?? null,
            enteredOn: attendance.enteredOn ?? null,
            note: attendance.note ?? '',
            takenBack: null,
        });
    }
    adjustmentsThisYear(member.adjustments, today).forEach((adjustment, i) => {
        rows.set(`adjustment:${i}`, {
            id: `adjustment-${i}`,
            name: adjustment.note || 'Adjustment from E-Board',
            date: adjustment.date ?? '',
            eventType: 'Adjustment',
            source: 'adjustment',
            vePoints: adjustment.points || 0,
            cabinetPoints: 0,
            codeId: null,
            requestId: adjustment.requestId ?? null,
            ...(adjustment.by ? { approvedBy: adjustment.by, approvedOn: adjustment.date ?? null } : reviewOf(adjustment.requestId)),
            enteredBy: null,
            enteredOn: null,
            note: '',
            takenBack: null,
        });
    });
    for (const removed of removedThisYear(member, attendances, today)) {
        const type = eventType(removed.eventTypeId);
        rows.set(`removed:${removed.codeId}`, {
            id: `removed-${removed.codeId}`,
            name: removed.event,
            date: removed.eventDate,
            eventType: type?.label ?? 'Unknown Event Type',
            source: 'code',
            vePoints: type?.vePoints ?? 0,
            cabinetPoints: type?.cabinetPoints ?? 0,
            codeId: removed.codeId,
            requestId: null,
            approvedBy: null,
            approvedOn: null,
            enteredBy: null,
            enteredOn: null,
            note: '',
            takenBack: { kind: 'removed', reason: removed.reason, by: removed.by, on: removed.on, ...(removed.superseded ? { superseded: true } : {}) },
        });
    }
    const { start, end } = academicYear(today);
    for (const request of requests) {
        if (!request.revoked || !request.date || request.date < start || request.date > end) continue;
        const type = request.adjustment ? undefined : eventType(request.eventTypeId);
        // The same number of Attendances as it earned VE Points for (a Tabling request's hours).
        const count = type?.vePoints ? request.revoked.points / type.vePoints : 1;
        rows.set(`revoked:${request.id}`, {
            id: `revoked-${request.id}`,
            name: request.activityName || 'Point Request',
            date: request.date,
            eventType: type?.label ?? 'Adjustment',
            source: request.adjustment ? 'adjustment' : 'request',
            vePoints: request.revoked.points,
            cabinetPoints: (type?.cabinetPoints ?? 0) * count,
            codeId: request.codeId ? request.codeId.toUpperCase() : null,
            requestId: request.id,
            approvedBy: request.revoked.approvedBy,
            approvedOn: null,
            enteredBy: null,
            enteredOn: null,
            note: '',
            takenBack: { kind: 'revoked', reason: request.reviewNotes ?? '', by: request.reviewedBy ?? null, on: request.reviewedOn ?? null },
        });
    }

    const sorted = [...rows.values()].sort((a, b) => byDateNewestFirst(a, b) || b.id.localeCompare(a.id));
    const counted = sorted.filter((row) => !row.takenBack);
    return {
        rows: sorted,
        counted: counted.length,
        vePoints: counted.reduce((sum, row) => sum + row.vePoints, 0),
        cabinetPoints: counted.reduce((sum, row) => sum + row.cabinetPoints, 0),
        adjustments: counted.filter((row) => row.source === 'adjustment').length,
        codes: {
            redeemed: counted.filter((row) => row.codeId).length,
            byRequest: counted.filter((row) => row.codeId && row.source === 'request').length,
        },
    };
}

/** What removing one check-in would change, for E-Board to see before confirming. */
export type RemovalEffect = {
    vePoints: number;
    cabinetPoints: number;
    /** Core Events it turns into Missed Events. */
    missed: string[];
    /** Open Strikes it adds. */
    strikes: number;
    /** Missed Events it had made up, owed again. */
    owedAgain: string[];
};

/** A Core Event is only missed once its day is over, so a change to an event today is judged as of tomorrow. */
function judgedOn(eventDate: string, today: string): string {
    return eventDate < today ? today : dayAfter(eventDate);
}

function dayAfter(isoDate: string): string {
    const date = fromIsoDate(isoDate);
    date.setDate(date.getDate() + 1);
    return toIsoDate(date);
}

/** What a Member's standing is computed from, for one school year. */
export type StandingFacts = { member: Member; attendances: Attendance[]; codes: Code[]; today: string };

/** Works out a Removed Check-in's effect by computing the standing with and without its Attendance. */
export function checkInRemovalEffect(
    { member, attendances, codes, today }: StandingFacts,
    attendanceId: string,
): RemovalEffect {
    const asOf = judgedOn(attendances.find((attendance) => attendance.id === attendanceId)?.eventDate ?? today, today);
    const before = computeStanding(member, attendances, rubric, codes, { today: asOf });
    const after = computeStanding(member, attendances.filter((attendance) => attendance.id !== attendanceId), rubric, codes, { today: asOf });
    const codeById = codesById(codes);
    const nameOf = (missed: MissedEvent) => codeById.get(missed.codeId.toUpperCase())?.event || missed.codeId;
    const beforeByCode = new Map(before.missedEvents.map((missed) => [missed.codeId.toUpperCase(), missed]));
    return {
        vePoints: before.vePoints - after.vePoints,
        cabinetPoints: before.cabinetPoints - after.cabinetPoints,
        missed: after.missedEvents.filter((missed) => !beforeByCode.has(missed.codeId.toUpperCase())).map(nameOf),
        strikes: after.openStrikes - before.openStrikes,
        owedAgain: after.missedEvents
            .filter((missed) => missed.owed && beforeByCode.get(missed.codeId.toUpperCase())?.owed === false)
            .map(nameOf),
    };
}

/** What entering an event would change, for E-Board to see before confirming. */
export type EntryEffect = {
    vePoints: number;
    cabinetPoints: number;
    /** Missed Events it clears: the Member did attend that Core Event. */
    cleared: string[];
    /** Missed Events it makes up. */
    madeUp: string[];
    /** Open Strikes it removes. */
    strikesCleared: number;
};

/** Works out an Entered Attendance's effect by computing the standing with and without it. */
export function entryEffect({ member, attendances, codes, today }: StandingFacts, entered: Attendance[]): EntryEffect {
    const asOf = judgedOn(entered.map((attendance) => attendance.eventDate).sort().pop() ?? today, today);
    const before = computeStanding(member, attendances, rubric, codes, { today: asOf });
    const after = computeStanding(member, [...attendances, ...entered], rubric, codes, { today: asOf });
    const codeById = codesById(codes);
    const nameOf = (missed: MissedEvent) => codeById.get(missed.codeId.toUpperCase())?.event || missed.codeId;
    const afterByCode = new Map(after.missedEvents.map((missed) => [missed.codeId.toUpperCase(), missed]));
    const closed = before.missedEvents.filter((missed) => missed.owed && !afterByCode.get(missed.codeId.toUpperCase())?.owed);
    return {
        vePoints: after.vePoints - before.vePoints,
        cabinetPoints: after.cabinetPoints - before.cabinetPoints,
        cleared: closed.filter((missed) => !afterByCode.has(missed.codeId.toUpperCase())).map(nameOf),
        madeUp: closed.filter((missed) => afterByCode.has(missed.codeId.toUpperCase())).map(nameOf),
        strikesCleared: before.openStrikes - after.openStrikes,
    };
}

export type RequestStatus = 'pending' | 'approved' | 'denied';

const STATUS_LABEL: Record<RequestStatus, string> = { pending: 'Pending', approved: 'Approved', denied: 'Denied' };

export type LookupRequest = {
    id: string;
    name: string;
    date: string;
    status: RequestStatus;
    statusLabel: string;
    /** What it asks for while pending; what it earned once reviewed (0 if denied). */
    points: number;
    pointsLabel: 'requested' | 'credited';
    /** The Event Type E-Board confirmed, or the Member's pick while pending. */
    eventType: string;
    reviewedBy: string | null;
    reviewedOn: string | null;
    /** The deny or revoke reason, or an Adjustment's note. */
    notes: string;
    /** Approved as an Attendance or an Adjustment, so E-Board can still take it back. */
    revocable: boolean;
    revoked: Revoked | null;
};

/**
 * The Member's Point Requests from this school year, plus any older one still
 * pending (it still needs a review): pending first, then newest first.
 */
export function lookupRequests(requests: MemberRequest[], today: string): LookupRequest[] {
    const { start, end } = academicYear(today);
    return requests
        .filter((request) => request.status === 'pending' || !request.date || (request.date >= start && request.date <= end))
        .map((request): LookupRequest => {
            const status: RequestStatus = request.status === 'approved' || request.status === 'denied' ? request.status : 'pending';
            const type = request.adjustment ? 'Adjustment'
                : request.eventTypeId ? eventType(request.eventTypeId)?.label ?? request.eventTypeId : 'Not listed';
            return {
                id: request.id,
                name: request.activityName || 'Point Request',
                date: request.date ?? '',
                status,
                statusLabel: request.revoked ? 'Revoked' : STATUS_LABEL[status],
                points: status === 'denied' ? 0 : request.pointsRequested ?? 0,
                pointsLabel: status === 'pending' ? 'requested' : 'credited',
                eventType: type,
                reviewedBy: request.reviewedBy ?? null,
                reviewedOn: request.reviewedOn ?? null,
                notes: request.reviewNotes ?? '',
                revocable: canRevoke(request),
                revoked: request.revoked ?? null,
            };
        })
        .sort((a, b) => Number(b.status === 'pending') - Number(a.status === 'pending')
            || byDateNewestFirst(a, b) || a.id.localeCompare(b.id));
}

/** Approved on the old review page, a request's points are only in the old counters: nothing to take back. */
export function canRevoke(request: Pick<MemberRequest, 'status' | 'adjustment' | 'attendanceIds'>): boolean {
    return request.status === 'approved' && Boolean(request.adjustment || request.attendanceIds);
}

export type LookupSummary = {
    /** Which rules the Member is held to: E-Board is exempt from the Cabinet ones. */
    rules: 'general' | 'cabinet' | 'exempt';
    vePoints: number;
    veGoal: number;
    veReached: boolean;
    /** Pending Point Requests never count toward the Total Points. */
    pendingCount: number;
    pendingPoints: number;
    cabinetPoints: number;
    cabinetGoal: number;
    openStrikes: number;
    atRisk: boolean;
    /** Missed Events still needing a Make-up. */
    missedOwed: number;
    /** Every Missed Event this year, split by whether E-Board excused it. */
    missedExcused: number;
    missedUnexcused: number;
    /** Semester Requirements met out of those not waived. */
    requirements: Record<Semester, { met: number; total: number }>;
};

export function lookupSummary(member: Member, standing: Standing, requests: MemberRequest[]): LookupSummary {
    const pending = requests.filter((request) => request.status === 'pending');
    const requirementsOf = (semester: Semester) => {
        const rows = standing.semesterRequirements[semester].filter((req) => !req.waived);
        return { met: rows.filter((req) => req.met).length, total: rows.length };
    };
    return {
        rules: standing.heldToCabinetRules ? 'cabinet' : member.eboard ? 'exempt' : 'general',
        vePoints: standing.vePoints,
        veGoal: standing.veGoal,
        veReached: standing.vePoints >= standing.veGoal,
        pendingCount: pending.length,
        pendingPoints: pending.reduce((sum, request) => sum + (request.pointsRequested ?? 0), 0),
        cabinetPoints: standing.cabinetPoints,
        cabinetGoal: CABINET_POINTS_GOAL,
        openStrikes: standing.openStrikes,
        atRisk: standing.openStrikes >= AT_RISK_STRIKES,
        missedOwed: standing.missedEvents.filter((missed) => missed.owed).length,
        missedExcused: standing.missedEvents.filter((missed) => missed.excused).length,
        missedUnexcused: standing.missedEvents.filter((missed) => !missed.excused).length,
        requirements: { fall: requirementsOf('fall'), spring: requirementsOf('spring') },
    };
}

export type MissedState = 'strike' | 'open' | 'madeup' | 'closed';

/** In display order: open Strikes, other open misses, Make-ups, then closed. */
export const MISSED_STATE_LABEL: Record<MissedState, string> = {
    strike: 'Missed, Strike',
    open: 'Missed, needs a Make-up',
    madeup: 'Made up',
    closed: 'Closed by E-Board',
};

const STATE_ORDER = Object.keys(MISSED_STATE_LABEL) as MissedState[];

export type MissedEventRow = {
    codeId: string;
    name: string;
    eventDate: string;
    state: MissedState;
    excused: boolean;
    /** The event that made it up, or null. */
    madeUpBy: { name: string; date: string } | null;
};

function missedState(missed: MissedEvent): MissedState {
    if (missed.overridden) return 'closed';
    if (missed.madeUpBy) return 'madeup';
    return missed.strike ? 'strike' : 'open';
}

/** A Cabinet Member's Missed Events: open ones first (Strikes before the rest), then Make-ups, then closed; oldest first within each. */
export function missedEventRows(standing: Standing, codes: Code[], attendances: Attendance[]): MissedEventRow[] {
    const codeById = codesById(codes);
    const attendanceById = new Map(attendances.map((attendance) => [attendance.id, attendance]));
    const nameOf = (codeId: string | undefined, eventTypeId: string) =>
        (codeId && codeById.get(codeId.toUpperCase())?.event) || eventType(eventTypeId)?.label || codeId || 'Event';
    return standing.missedEvents
        .map((missed) => {
            const cover = missed.madeUpBy ? attendanceById.get(missed.madeUpBy) : undefined;
            return {
                codeId: missed.codeId,
                name: nameOf(missed.codeId, missed.eventTypeId),
                eventDate: missed.eventDate,
                state: missedState(missed),
                excused: missed.excused,
                madeUpBy: cover ? { name: nameOf(cover.codeId, cover.eventTypeId), date: cover.eventDate } : null,
            };
        })
        .sort((a, b) => STATE_ORDER.indexOf(a.state) - STATE_ORDER.indexOf(b.state) || a.eventDate.localeCompare(b.eventDate));
}
