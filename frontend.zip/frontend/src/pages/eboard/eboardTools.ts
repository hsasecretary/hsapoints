// The E-Board tools, each on its own page under /eboard. Used by the routes
// in App.tsx, the Account menu's E-Board list in SiteHeader and the /eboard landing page
// (EboardHome), so they stay in sync.
export const EBOARD_TOOLS = [
    { path: 'event-codes', label: 'Event Codes' },
    { path: 'point-requests', label: 'Point Request Review' },
    { path: 'user-lookup', label: 'User Lookup' },
    { path: 'excuse-absence', label: 'Excuse Absence' },
    { path: 'approvals', label: 'E-Board Member Approval' },
] as const;
